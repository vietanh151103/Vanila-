VanillaRPG Resource Pack v1.1 - Minecraft Java 26.2

Fixed from v1:
- Resource Pack version is 88.0 for Minecraft 26.2.
- Uses the modern assets/minecraft/items/*.json item-model system.
- Keeps compatibility with VanillaRPG-Core 0.2.7 CustomModelData IDs.

Custom models:
12001 Ashbringer
12002 Bloodreaver
12101 Epic Essence Shard
12102 Legendary Starshard
12103 Crimson Mythic Heartcore
12201 Blueprint: Ashbringer
12202 Blueprint: Bloodreaver

Install locally:
Put the ZIP directly into .minecraft/resourcepacks and enable it.
Do not unzip the ZIP into another nested folder.
