VanillaRPG Resource Pack v1

This pack adds custom models/textures for:
- Ashbringer
- Bloodreaver
- Epic Essence Shard
- Legendary Starshard
- Crimson Mythic Heartcore
- Blueprint: Ashbringer
- Blueprint: Bloodreaver

Requires VanillaRPG plugin 0.2.7+ because the plugin must set CustomModelData.
If Minecraft warns about pack format, edit pack.mcmeta and change pack_format to match your client.
